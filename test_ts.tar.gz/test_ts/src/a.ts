export default class A {
  message: string = 'Hello!'

}
