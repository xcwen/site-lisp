
import A from 'Hello/a'
export default class B {
  message: string = 'Hello B!'

}
