add to   .vimrc
	source ~/.vim/comm.vim


"===========================
let g:Author="jim"
let g:Email="jim@taomee.com"
let g:Company="TAOMEE"
"===========================

