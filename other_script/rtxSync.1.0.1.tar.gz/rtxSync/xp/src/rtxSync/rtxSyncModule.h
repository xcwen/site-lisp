#pragma once

// rtxSyncModule.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CrtxSyncModule command target

class CrtxSyncModule : public CCmdTarget
{
	DECLARE_DYNCREATE(CrtxSyncModule)
	DECLARE_EVENT_RECEIVER(CrtxSyncModule)

	CrtxSyncModule();           // protected constructor used by dynamic creation

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CrtxSyncModule)
	public:
	virtual void OnFinalRelease();
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CrtxSyncModule();

	// Generated message map functions
	//{{AFX_MSG(CrtxSyncModule)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	BEGIN_DUAL_INTERFACE_PART(RTXCModule, IRTXCPlugin)
		STDMETHOD(get_Identifier)(BSTR *pVal)
		{
			METHOD_PROLOGUE(CrtxSyncModule, RTXCModule)
				
			return pThis->get_Identifier(pVal);
		}

		STDMETHOD(get_Name)(BSTR *pVal)
		{
			METHOD_PROLOGUE(CrtxSyncModule, RTXCModule)
				
			return pThis->get_Name(pVal);
		}

		STDMETHOD(get_ModuleSite)(IDispatch* *pVal)
		{
			METHOD_PROLOGUE(CrtxSyncModule, RTXCModule)
		
			return pThis->get_ModuleSite(pVal);
		}

		STDMETHOD(OnLoad)(IDispatch* RTXCModuleSite)
		{
			METHOD_PROLOGUE(CrtxSyncModule, RTXCModule)
			
			return pThis->OnLoad(RTXCModuleSite);
		}

		STDMETHOD(OnAccountChange)()
		{
			METHOD_PROLOGUE(CrtxSyncModule, RTXCModule)
				
			return pThis->OnAccountChange();
		}
		
		STDMETHOD(OnInvoke)(VARIANT Receiver, VARIANT Parameter, VARIANT Extra, VARIANT* Result)
		{
			METHOD_PROLOGUE(CrtxSyncModule, RTXCModule)
				
			return pThis->OnInvoke(Receiver, Parameter, Extra, Result);
		}
		
		STDMETHOD(OnUnload)(enum RTXC_MODULE_UNLOAD_REASON Reason)
		{
			METHOD_PROLOGUE(CrtxSyncModule, RTXCModule)
				
			return pThis->OnUnload(Reason);
		}

		STDMETHOD(get_Info)(enum RTXC_PLUGIN_INFO_FIELD Field, BSTR *pVal)
		{
			METHOD_PROLOGUE(CrtxSyncModule, RTXCModule)

			return pThis->get_Info(Field, pVal);
		}
	END_DUAL_INTERFACE_PART(RTXCModule)	
	
	DECLARE_MESSAGE_MAP()
	DECLARE_OLECREATE(CrtxSyncModule)

	// Generated OLE dispatch map functions
	//{{AFX_DISPATCH(CrtxSyncModule)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
private:
	IRTXCRootPtr m_ptrRoot;
	IRTXCModuleSitePtr m_ptrModuleSite;

	CRTXCEventSinkRoot m_RootEventSink;

	void OnLoginResult(RTXC_LOGIN_RESULT Result);
	HRESULT OnMsgCountChange(long Count, VARIANT_BOOL Forbid, 
							  LPCTSTR Identifier, LPCTSTR Key, BSTR Sender);
	HRESULT get_Identifier(BSTR* pVal);
	HRESULT get_Name(BSTR* pVal);

	HRESULT get_ModuleSite(IDispatch* *pVal);

	HRESULT OnLoad(IDispatch* RTXCModuleSite);
	
	HRESULT OnAccountChange();

	HRESULT OnInvoke(VARIANT Receiver, VARIANT Parameter, VARIANT Extra, VARIANT* Result);
	
	HRESULT OnUnload(enum RTXC_MODULE_UNLOAD_REASON Reason);

	HRESULT get_Info(enum RTXC_PLUGIN_INFO_FIELD Field, BSTR *pVal);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
