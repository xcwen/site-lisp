// rtxSyncModule.cpp : implementation file
//

#include "stdafx.h"
#include "rtxSync.h"
#include "rtxSyncModule.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CrtxSyncModule

IMPLEMENT_DYNCREATE(CrtxSyncModule, CCmdTarget)
DELEGATE_DUAL_INTERFACE(CrtxSyncModule, RTXCModule)

CrtxSyncModule::CrtxSyncModule()
{
	EnableAutomation();
	
	// To keep the application running as long as an OLE automation 
	//	object is active, the constructor calls AfxOleLockApp.
	
	AfxOleLockApp();
}

CrtxSyncModule::~CrtxSyncModule()
{
	// To terminate the application when all objects created with
	// 	with OLE automation, the destructor calls AfxOleUnlockApp.
	
	AfxOleUnlockApp();
}

void CrtxSyncModule::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CCmdTarget::OnFinalRelease();
}

BEGIN_MESSAGE_MAP(CrtxSyncModule, CCmdTarget)
	//{{AFX_MSG_MAP(CrtxSyncModule)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CrtxSyncModule, CCmdTarget)
	//{{AFX_DISPATCH_MAP(CrtxSyncModule)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

BEGIN_INTERFACE_MAP(CrtxSyncModule, CCmdTarget)
	INTERFACE_PART(CrtxSyncModule, IID_IRTXCModule, RTXCModule)
	INTERFACE_PART(CrtxSyncModule, IID_IRTXCPlugin, RTXCModule)
END_INTERFACE_MAP()

// {37B85DD8-0454-467B-BBF2-985E85EE1E0F}
IMPLEMENT_OLECREATE(CrtxSyncModule, "RTXC.rtxSyncModule", 
	0x37b85dd8, 0x454, 0x467b, 0xbb, 0xf2, 0x98, 0x5e, 0x85, 0xee, 0x1e, 0xf)

/////////////////////////////////////////////////////////////////////////////
// CrtxSyncModule message handlers

HRESULT CrtxSyncModule::get_Identifier(BSTR* pVal)
{
	RTX_CHECK_INVALIDARG_NULL(pVal);
	
	*pVal = CString(RTX_MODULE_IDENTIFIER_RTXSYNC).AllocSysString();
	
	return S_OK;
}

HRESULT CrtxSyncModule::get_Name(BSTR* pVal)
{
	RTX_CHECK_INVALIDARG_NULL(pVal);
	
	*pVal = CString(RTX_MODULE_NAME_RTXSYNC).AllocSysString();
	
	return S_OK;
}

HRESULT CrtxSyncModule::get_ModuleSite(IDispatch* *pVal)
{
	RTX_CHECK_INVALIDARG_NULL(pVal);
				
	*pVal = (IDispatch*)m_ptrModuleSite;
	
	if (*pVal != NULL)
	{
		(*pVal)->AddRef();
		
		return S_OK;
	}
				
	return E_FAIL;
}

HRESULT CrtxSyncModule::OnLoad(IDispatch* RTXCModuleSite)
{
	RTX_CHECK_INVALIDARG_NULL(RTXCModuleSite);

	RTX_TRY
	{
		m_ptrModuleSite = RTXCModuleSite;
		m_ptrRoot = m_ptrModuleSite->RTXCRoot;

		m_RootEventSink.HookEvent(evt_OnLoginResult, this, &CrtxSyncModule::OnLoginResult);
		m_RootEventSink.HookEvent(evt_OnMsgCountChange, this, &CrtxSyncModule::OnMsgCountChange);

		VERIFY(m_RootEventSink.Advise(m_ptrRoot));

		return S_OK;
	}
	RTX_CATCH_ALL(return E_FAIL)
}

HRESULT CrtxSyncModule::OnAccountChange()
{
	return S_OK;
}

HRESULT CrtxSyncModule::OnInvoke(VARIANT Receiver, 
								  VARIANT Parameter, VARIANT Extra, VARIANT* Result)
{
	return S_OK;
}

HRESULT CrtxSyncModule::OnUnload(enum RTXC_MODULE_UNLOAD_REASON Reason)
{
	VERIFY(m_RootEventSink.Unadvise());
	m_RootEventSink.UnhookEvent(evt_OnLoginResult, this, &CrtxSyncModule::OnLoginResult);
	m_RootEventSink.UnhookEvent(evt_OnMsgCountChange, this, &CrtxSyncModule::OnMsgCountChange);

	return S_OK;
}

HRESULT CrtxSyncModule::get_Info(enum RTXC_PLUGIN_INFO_FIELD Field, BSTR *pVal)
{
	RTX_CHECK_INVALIDARG_NULL(pVal);

	*pVal = NULL;

	if (Field == RTXC_PLUGIN_INFO_FIELD_DESCRIPTION)
	{
		*pVal = CString(RTX_MODULE_DESCRIPTION_RTXSYNC).AllocSysString();
	}

	return S_OK;
}

void CrtxSyncModule::OnLoginResult(RTXC_LOGIN_RESULT Result)
{
	
}
void debuglog(const char * msg)
{
	FILE * fp=fopen("C:\\log.txt","a+");
	fprintf(fp,"==:%s\n",msg);
	fclose(fp);
}
#include   <Winsock2.h>

HRESULT CrtxSyncModule::OnMsgCountChange(long Count, VARIANT_BOOL Forbid, 
							  LPCTSTR Identifier, LPCTSTR Key, BSTR Sender)
{
	char ip[32];
	int port;
	FILE * fp=fopen("C:\\rtxsync.txt","a+");
	if (fp==NULL) return S_OK;

	fscanf(fp,"%s %d",ip,&port);
	fclose(fp);	


	WORD   wVersionRequested;
	WSADATA   wsaData;
	int   err;
	wVersionRequested   =   MAKEWORD(   1,   1   );
	err   =   WSAStartup(   wVersionRequested,   &wsaData   );
	if   (   err   !=   0   )   {return S_OK;}


	if   (   LOBYTE(   wsaData.wVersion   )   !=   1   ||
                HIBYTE(   wsaData.wVersion   )   !=   1   )   {
		WSACleanup(   );
		return S_OK;  
	}
	SOCKET   sockClient=socket(AF_INET,SOCK_DGRAM,0);

	SOCKADDR_IN   addrSrv;
	addrSrv.sin_addr.S_un.S_addr=inet_addr( ip);
	addrSrv.sin_family=AF_INET;
	addrSrv.sin_port=htons(port);
	//connect(sockClient,(SOCKADDR*)&addrSrv,sizeof(SOCKADDR));

	char buf[20];
	sprintf(buf,"%d",Count);
	sendto(sockClient, buf,strlen(buf),0, (SOCKADDR*)&addrSrv,sizeof(addrSrv) );
	closesocket(sockClient);
	WSACleanup(); 


	return S_OK;
}